# Code Wave · Sistema de Agendamento e Administração de Barbearias

Sistema multi-tenant em **Python (Flask + HTMX)**: cada barbearia tem seu link
(`/nome-da-barbearia/`), sua logo e suas cores. O cliente agenda pelo celular,
confirma o número com um código de 4 dígitos e recebe lembrete por WhatsApp.
O dono acompanha o dia, as comissões e os clientes que sumiram.

Os dados ainda ficam **em memória**: tudo passa por uma camada de repositórios
pronta para receber o banco de dados (veja [Banco de dados](#banco-de-dados)).

---

## Como rodar

Requisitos: Python 3.10 ou mais novo.

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env               # Windows: copy .env.example .env
python run.py
```

Abra **http://localhost:5000**. A página inicial lista as barbearias de demonstração.

| Barbearia | Página do cliente | Painel | Acessos (senha `demo123`) |
|---|---|---|---|
| Navalha de Ouro | `/navalha-de-ouro/` | `/navalha-de-ouro/admin/` | `dono@navalha.com` (dono) · `rafael@navalha.com` (barbeiro) |
| Corte Fino Barber Club | `/corte-fino/` | `/corte-fino/admin/` | `dono@cortefino.com` (dono) |

Os dados de demonstração voltam ao estado inicial sempre que o servidor reinicia.

### Testar o QR Code no celular

1. No `.env`, use `HOST=0.0.0.0` e `BASE_URL=http://IP-DA-SUA-MAQUINA:5000`.
2. Reinicie e abra **Painel → QR Code**. Celular e computador precisam estar na mesma rede.

### Testes automatizados

```bash
python -m pytest
```

São 33 testes cobrindo regras de agenda, fluxo do cliente, painel, isolamento
entre barbearias e proteções anti-trote. Eles também servem de contrato quando
o banco de dados for ligado.

---

## Onde está cada item do documento

### 1. Visão do Cliente

| Requisito | Onde |
|---|---|
| QR Code direto para o agendamento | `negocio/divulgacao.py`, rota `/<slug>/qrcode.png` e tela **Painel → QR Code** (cartaz para imprimir) |
| Nome, data, horário e serviço | `templates/cliente/agendar.html` + `rotas/cliente.py` |
| Escolha do barbeiro com portfólio | Cartões com até 2 fotos (toque para ampliar). Fotos enviadas em **Painel → Equipe** |
| Preço total antes de confirmar | Barra fixa com total e duração, recalculada pelo servidor a cada escolha (HTMX) |
| Validação anti-trote (código de 4 dígitos) | `negocio/agendamentos.py` + `negocio/verificacao.py`. Limites: 5 tentativas, reenvio a cada 60 s, 5 códigos por hora e 3 horários ativos por número |
| Lembrete com confirmar/cancelar | `tarefas.py` (`processar_lembretes`), X horas antes, configurável por barbearia |
| Reagendamento autônomo | Link do comprovante: `/<slug>/agendamento/<token>` com Remarcar e Cancelar |

### 2. Visão Administrativa

| Requisito | Onde |
|---|---|
| Dashboard do dia | `negocio/agenda.py` (`montar_quadro`) + `templates/admin/_quadro.html`. Mostra colunas por barbeiro, horários livres, ocupação e faturamento previsto, e atualiza sozinho a cada minuto |
| Financeiro e comissões | `negocio/financeiro.py`. Fechamento por dia, semana ou mês. A comissão fica registrada na conclusão de cada atendimento |
| Controle de agenda (bloqueios) | Botão **Bloquear** em cada horário livre do quadro e página **Bloqueios** com atalhos (almoço, pausa, imprevisto, dia inteiro) |
| Mini CRM | `negocio/crm.py`. Mostra frequência e inativos (após X dias, configurável), com campanha de reativação por WhatsApp |

### 3. Modelo de negócio e estrutura técnica

| Requisito | Onde |
|---|---|
| Multi-tenant com link único | `app/__init__.py` (`_configurar_tenant`): toda URL `/<slug>/...` carrega a barbearia. Cadastro de novas barbearias em `/cadastro` |
| White-label | **Painel → Configurações**: logo e duas cores, com prévia ao vivo. O contraste do texto é calculado automaticamente |
| Filas para mensagens | `tarefas.py`: `FilaDeMensagens` + `AgendadorDeLembretes`. Cada envio fica registrado em **Painel → Mensagens** |

---

## Arquitetura

O documento previa Laravel + Livewire. Esta é a correspondência em Python:

| Laravel | Aqui |
|---|---|
| Rotas + Controllers | `app/rotas/` (Blueprints do Flask) |
| Blade | `app/templates/` (Jinja2) |
| Livewire | HTMX: o HTML continua sendo gerado em Python, sem API nem front-end separado |
| Services / Actions | `app/negocio/` (não depende do Flask, fácil de testar) |
| Eloquent | `app/repositorios/` (contratos em `base.py`, implementação em memória) |
| Queues / Jobs / Scheduler | `app/tarefas.py` (troque por RQ ou Celery em produção) |
| Service Container | `app/contexto.py` |
| Middleware de autenticação | `app/seguranca.py` |

```
codewave-barbearia/
├── run.py                  inicia o servidor
├── config.py               configurações (lidas do .env)
├── requirements.txt
├── database/schema.sql     esquema PostgreSQL planejado (validado no PostgreSQL 16)
├── app/
│   ├── __init__.py         create_app: monta dependências, tenant, rotas e tarefas
│   ├── models.py           entidades (viram tabelas)
│   ├── contexto.py         acesso a repositório, notificador e relógio da barbearia
│   ├── seguranca.py        CSRF, login, permissões, cabeçalhos
│   ├── filtros.py          filtros Jinja (moeda, datas, telefone...)
│   ├── tarefas.py          fila de mensagens e lembretes automáticos
│   ├── seed.py             dados de demonstração
│   ├── utils.py            formatos brasileiros, telefone, cores, datas
│   ├── repositorios/       base.py (contratos) e memoria.py (implementação atual)
│   ├── negocio/            agenda, agendamentos, verificação, notificações,
│   │                       financeiro, crm, barbearias, divulgação, arquivos
│   ├── rotas/              publico.py, cliente.py, admin.py
│   ├── templates/          base, publico/, cliente/, admin/
│   └── static/             css/ (base, cliente, admin), js/app.js, uploads/
└── tests/                  pytest
```

---

## Banco de dados

O sistema foi escrito para que o banco entre **sem mexer em rotas nem em regras**.

1. Instale as dependências, que já estão comentadas no `requirements.txt`:
   `pip install SQLAlchemy "psycopg[binary]" alembic`
2. Crie o banco a partir de `database/schema.sql`, ou gere as migrações com o Alembic usando o arquivo como referência.
3. Crie `app/repositorios/sql.py` implementando as mesmas classes de `repositorios/base.py`.
   - Cada método vira uma consulta, sempre filtrando por `barbearia_id`.
   - `transacao()` vira `session.begin()`.
4. Em `repositorios/__init__.py`, faça `criar_repositorio()` devolver o repositório SQL quando houver `DATABASE_URL` no `.env`.
5. Rode `python -m pytest`. Se os testes passarem, o comportamento continua o mesmo.

Algumas garantias já estão no próprio esquema:
- Dois clientes confirmando o mesmo horário ao mesmo tempo não geram agendamento duplicado (constraint `agendamentos_sem_sobreposicao`).
- Um agendamento nunca aponta para barbeiro ou cliente de outra barbearia.
- O celular do cliente é único por barbearia.

Com o banco ligado:
- Rode os lembretes num processo separado, com cron a cada minuto: `flask --app run lembretes`.
- Use `AGENDADOR_ATIVO=0` no servidor web.
- Troque a `FilaDeMensagens` por RQ ou Celery com Redis.

---

## WhatsApp e SMS

Por padrão as mensagens saem no **console**: aparecem no terminal e em **Painel → Mensagens**. Em modo demonstração, o código também é mostrado na tela. Para enviar de verdade, configure no `.env`:

| Provedor | Variáveis |
|---|---|
| Twilio (SMS e WhatsApp) | `PROVEDOR_SMS=twilio`, `PROVEDOR_WHATSAPP=twilio`, `TWILIO_*` |
| WhatsApp Cloud API (Meta) | `PROVEDOR_WHATSAPP=meta`, `META_WHATSAPP_TOKEN`, `META_WHATSAPP_PHONE_ID` |

No WhatsApp oficial, mensagens que a empresa inicia precisam de **templates aprovados pela Meta**: código de verificação, lembrete e campanha. Use os textos de `negocio/notificacoes.py` como base para cadastrá-los.

Os links de confirmar e cancelar abrem a página do comprovante, e a ação só acontece com um toque no botão. Isso é proposital: a pré-visualização de links do WhatsApp acessa a URL sozinha e confirmaria ou cancelaria o horário sem o cliente perceber.

Desligue `MODO_DEMO` em produção.

---

## Segurança incluída

- **Requisições e login:**
  - proteção CSRF em todos os formulários e requisições HTMX;
  - senhas com hash (scrypt, do Werkzeug);
  - sessão renovada no login;
  - redirecionamento pós-login restrito ao próprio site.
- **Isolamento:** a sessão de uma barbearia não abre o painel de outra, e toda consulta filtra por `barbearia_id`.
- **Permissões:** o barbeiro vê a agenda e cuida só dos próprios horários e bloqueios.
- **Uploads:** só imagens PNG, JPG, WEBP ou GIF, conferidas pelos bytes do arquivo. SVG é recusado.
- **Cores e cabeçalhos:**
  - as cores do white-label são validadas como `#RRGGBB` antes de entrar no CSS;
  - cabeçalhos `X-Content-Type-Options`, `X-Frame-Options` e `Referrer-Policy`.

### Antes de ir para produção

- **Variáveis de ambiente:** defina uma `SECRET_KEY` forte, `SESSION_COOKIE_SECURE=1`, `DEBUG=0` e `MODO_DEMO=0`.
- **Infraestrutura:** banco de dados, HTTPS e `gunicorn "run:app"`.
- **Uploads:** guarde as imagens num armazenamento externo (por exemplo, S3).
- **Login:** limite as tentativas, por exemplo com Flask-Limiter.
